# Project 4
from soccer import *
game = Soccer(-800, 800, 0, 600)
game.play()
