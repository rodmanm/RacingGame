# Racing
 A simple game


# Directions:
Use python3 with turtle to launch main.py

The arrow keys can control the turtle, and the turtle drives around and eats stuff. Nothing interesting.

Oh, C can stop the game cleanly in case the X doesn't work.

At some point L might do stuff, but probably not.

Space is going to be to fire lasers if I decide to add that. 

Space might also be to jump. 

Currently this project is written using turtle, but I'd like to transition it at least partially to use pygame. 
Best case senario I would remove turtle entirely in favor of pygame. Turtle is just too slow, pygame is much faster. 

# Prerequesites
pip install pillow
pip install pygame